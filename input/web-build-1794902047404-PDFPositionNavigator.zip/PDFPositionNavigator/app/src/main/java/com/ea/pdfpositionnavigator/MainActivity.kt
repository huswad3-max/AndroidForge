package com.ea.pdfpositionnavigator

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("navigator", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showSettings()
    }

    private fun showSettings() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF7F7F7.toInt())
        }
        val title = TextView(this).apply {
            text = "PDF Position Navigator"
            textSize = 23f
            setTextColor(0xFF172033.toInt())
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "اضبط مقدار الحركة التي ينفذها الزران العائمان داخل تطبيقات PDF. النسبة محسوبة من ارتفاع الشاشة."
            textSize = 16f
            setTextColor(0xFF333333.toInt())
            setPadding(0, 14, 0, 18)
        })

        val mode = Spinner(this)
        val modes = listOf("نسبة من ارتفاع الشاشة (%)", "مسافة بالبكسل (px)")
        mode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)
        mode.setSelection(if (prefs.getString("mode", "percent") == "pixels") 1 else 0)
        root.addView(label("طريقة تحديد المسافة"))
        root.addView(mode)

        val amount = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "مثال: 85"
            setText(prefs.getInt("amount", 85).toString())
        }
        root.addView(label("المقدار (1 إلى 100 للنسبة، أو عدد البكسلات)"))
        root.addView(amount)

        val duration = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "مثال: 450"
            setText(prefs.getInt("duration", 450).toString())
        }
        root.addView(label("مدة حركة الإصبع بالمللي ثانية (150–1200)"))
        root.addView(duration)

        val save = Button(this).apply {
            text = "حفظ الإعدادات"
            setOnClickListener {
                val rawAmount = amount.text.toString().toIntOrNull() ?: 85
                val rawDuration = duration.text.toString().toIntOrNull() ?: 450
                val isPixels = mode.selectedItemPosition == 1
                val safeAmount = if (isPixels) rawAmount.coerceIn(1, 3000) else rawAmount.coerceIn(1, 100)
                val safeDuration = rawDuration.coerceIn(150, 1200)
                prefs.edit()
                    .putString("mode", if (isPixels) "pixels" else "percent")
                    .putInt("amount", safeAmount)
                    .putInt("duration", safeDuration)
                    .apply()
                amount.setText(safeAmount.toString())
                duration.setText(safeDuration.toString())
                Toast.makeText(this@MainActivity, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(save, matchWidth())

        val enable = Button(this).apply {
            text = "تفعيل أزرار التنقل العائمة"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(this@MainActivity, "فعّل PDF Position Navigator من خدمات إمكانية الوصول", Toast.LENGTH_LONG).show()
            }
        }
        root.addView(enable, matchWidth())
        root.addView(TextView(this).apply {
            text = "بعد التفعيل، ارجع إلى ملف PDF. اسحب لوحة الأزرار من شريطها لتحريكها. زر ↓ يحرك محتوى الصفحة إلى الأسفل (بإيماءة إصبع للأعلى)، وزر ↑ يعكس الحركة. زر ⚙ يفتح هذه الإعدادات، وزر × يخفي اللوحة مؤقتاً."
            textSize = 14f
            setTextColor(0xFF555555.toInt())
            setPadding(0, 18, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun label(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(0xFF222222.toInt())
        setPadding(0, 14, 0, 4)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        topMargin = 12
    }
}
