package com.ea.pdfpositionnavigator

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.Toast
import kotlin.math.roundToInt

class NavigatorAccessibilityService : AccessibilityService() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(0xE9222B3A.toInt(), 28f)
            setPadding(5, 5, 5, 5)
        }
        val handle = TextView(this).apply {
            text = "PDF ↕"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(7, 5, 7, 5)
            setOnTouchListener(DragTouchListener())
        }
        box.addView(handle)
        val up = makeButton("↑") { performScroll(up = true) }
        val down = makeButton("↓") { performScroll(up = false) }
        val settings = makeButton("⚙") {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        val hide = makeButton("×") { removePanel() }
        box.addView(up); box.addView(down); box.addView(settings); box.addView(hide)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12
            y = 260
        }
        try {
            windowManager.addView(box, params)
            panel = box
            panelParams = params
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر إظهار الأزرار العائمة", Toast.LENGTH_LONG).show()
        }
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 20f
        setTextColor(Color.WHITE)
        background = rounded(0xFF3B82F6.toInt(), 18f)
        minWidth = 48
        minimumWidth = 48
        minHeight = 46
        minimumHeight = 46
        setPadding(2, 0, 2, 0)
        setOnClickListener { action() }
    }

    private fun performScroll(up: Boolean) {
        val prefs = getSharedPreferences("navigator", MODE_PRIVATE)
        val metrics = resources.displayMetrics
        val screenH = metrics.heightPixels
        val mode = prefs.getString("mode", "percent") ?: "percent"
        val amount = prefs.getInt("amount", 85)
        val distance = if (mode == "pixels") amount else (screenH * amount / 100f).roundToInt()
        val duration = prefs.getInt("duration", 450).coerceIn(150, 1200).toLong()
        val x = metrics.widthPixels / 2f
        val margin = 24f * metrics.density
        val startY: Float
        val endY: Float
        if (up) {
            startY = margin
            endY = (startY + distance).coerceAtMost(screenH - margin)
        } else {
            startY = screenH - margin
            endY = (startY - distance).coerceAtLeast(margin)
        }
        if (kotlin.math.abs(startY - endY) < 2f) return
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun removePanel() {
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel = null
        panelParams = null
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0f
        private var startY = 0f
        private var initialX = 0
        private var initialY = 0
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = panelParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initialX = p.x; initialY = p.y
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = initialX - (event.rawX - startX).toInt()
                    p.y = initialY + (event.rawY - startY).toInt()
                    try { panel?.let { windowManager.updateViewLayout(it, p) } } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> return true
            }
            return false
        }
    }

    override fun onDestroy() {
        removePanel()
        super.onDestroy()
    }
}
